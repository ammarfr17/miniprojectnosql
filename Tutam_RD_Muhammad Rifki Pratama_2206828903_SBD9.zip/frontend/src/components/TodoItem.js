import React from 'react';

const TodoItem = ({ todo, deleteTodo }) => {
    return (
        <div>
            <div>
                <span>{todo.title}</span>
                <button onClick={() => deleteTodo(todo._id)}>Delete</button>
            </div>
        </div>
    );
};

export default TodoItem;








